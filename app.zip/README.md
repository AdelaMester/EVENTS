# NovaFutur
An event ticket management app

## Run application
```flask run```
